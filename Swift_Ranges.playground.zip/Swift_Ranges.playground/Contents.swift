import UIKit

var str = "Hello, Today we are dealing with Power Rangers ;-) Swift Ranges in playground"

//Closed Range Operators

let sampleRange: ClosedRange = 0...5
print(sampleRange.first!)
print(sampleRange.last!)

let nameList = ["Kumar", "Gopal","Lucky", "AMMU"]
for index in 0...2 {
    print ("Name \(index) is \(nameList[index])")
}

//CountableClosedRange
let countableCloseRange: CountableClosedRange = 0...2
print (nameList[countableCloseRange])


//Half-open range operator
let range: Range = 1..<4
print(range.first!)
print(range.last!)


//One-sided operator
print (...nameList.count)

print (nameList[0...])



//Prepare an array from an One-sided Range

let desiredNameListCount = 3
var newNameList : [String] = []
for index in 0... {
    guard newNameList.count != desiredNameListCount else {
        break
    }
    newNameList.append(nameList[index])
}
print(newNameList)


//Problem : First Character of the following emojiText
let emojiText: NSString = "🚀launcher"
print(emojiText.substring(with: NSRange(location: 0, length: 2)))


//It takes length as 2 , which means not every charater is of single length size..
//
//let emojiText = "🚀launcher"
//let endIndex = emojiText.index(emojiText.startIndex, offsetBy: 2)
//let range: Range<String.Index> = emojiText.startIndex..<endIndex
//print(emojiText[range]) //

//---> Above code snippet took from the source : https://www.avanderlee.com/swift/ranges-explained/

